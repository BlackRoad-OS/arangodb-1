////////////////////////////////////////////////////////////////////////////////
/// DISCLAIMER
///
/// Copyright 2014-2024 ArangoDB GmbH, Cologne, Germany
/// Copyright 2004-2014 triAGENS GmbH, Cologne, Germany
///
/// Licensed under the Business Source License 1.1 (the "License");
/// you may not use this file except in compliance with the License.
/// You may obtain a copy of the License at
///
///     https://github.com/arangodb/arangodb/blob/devel/LICENSE
///
/// Unless required by applicable law or agreed to in writing, software
/// distributed under the License is distributed on an "AS IS" BASIS,
/// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
/// See the License for the specific language governing permissions and
/// limitations under the License.
///
/// Copyright holder is ArangoDB GmbH, Cologne, Germany
///
/// @author Tobias Gödderz
////////////////////////////////////////////////////////////////////////////////

#pragma once

#include "Aql/BlocksWithClients.h"
#include "Aql/ExecutionBlockImpl.h"
#include "Aql/ExecutionNode/ScatterNode.h"
#include "Aql/RegisterInfos.h"

namespace arangodb {
namespace aql {

class SkipResult;
class ExecutionEngine;
class ScatterNode;

class ScatterExecutorInfos : public ClientsExecutorInfos {
 public:
  explicit ScatterExecutorInfos(std::vector<std::string> clientIds);
  ScatterExecutorInfos(ScatterExecutorInfos&&) = default;
};

// The ScatterBlock is actually implemented by specializing ExecutionBlockImpl,
// so this class only exists to identify the specialization.
class ScatterExecutor {
 public:
  using Infos = ScatterExecutorInfos;

  class ClientBlockData {
   public:
    ClientBlockData(ExecutionEngine& engine, ExecutionNode const* node,
                    RegisterInfos const& scatterInfos);

    auto clear() -> void;
    auto addBlock(SharedAqlItemBlockPtr block, SkipResult skipped) -> void;
    auto hasDataFor(AqlCall const& call) -> bool;

    auto execute(AqlCallStack const& callStack, ExecutionState upstreamState)
        -> std::tuple<ExecutionState, SkipResult, SharedAqlItemBlockPtr>;

    auto remainingRows() const -> uint64_t;

    /**
     * @brief Check if we have received a hard limit
     * @return true if we have received a hard limit
     */
    auto gotHardLimit() const -> bool;

    /**
     * @brief Reset the hard limit
     */
    auto resetHardLimit() -> void;

    /**
     * @brief Set hard limit has been seen.
     */
    auto setSeenHardLimit() -> void;

   private:
    std::deque<std::tuple<SharedAqlItemBlockPtr, SkipResult>> _queue;
    // This is unique_ptr to get away with everything being forward declared...
    std::unique_ptr<ExecutionBlock> _executor;
    bool _executorHasMore;
    bool _gotHardLimit = false;
  };

  explicit ScatterExecutor(Infos const&);
  ~ScatterExecutor() = default;

  auto distributeBlock(
      SharedAqlItemBlockPtr const& block, SkipResult skipped,
      std::unordered_map<std::string, ClientBlockData>& blockMap) const -> void;
};

/**
 * @brief See ExecutionBlockImpl.h for documentation.
 */
template<>
class ExecutionBlockImpl<ScatterExecutor>
    : public BlocksWithClientsImpl<ScatterExecutor> {
 public:
  ExecutionBlockImpl(ExecutionEngine* engine, ScatterNode const* node,
                     RegisterInfos registerInfos,
                     ScatterExecutor::Infos&& infos);

  ~ExecutionBlockImpl() override = default;
};

}  // namespace aql
}  // namespace arangodb
